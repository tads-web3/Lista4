package br.edu.ifpr.biblioteca_spring.models;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class Livro {

    private Long id;

    @NotBlank(message = "O título não pode estar em branco.")
    @Size(min = 2, max = 100, message = "O título deve ter entre 2 e 100 caracteres.")
    private String titulo;

    @NotBlank(message = "O autor não pode estar em branco.")
    @Size(min = 2, max = 50, message = "O autor deve ter entre 2 e 50 caracteres.")
    private String autor;

    private boolean disponivel;

    public Livro(){}

    public Livro(Long id, String titulo, String autor) {
        this.id = id;
        this.titulo = titulo;
        this.autor = autor;
        this.disponivel = true;
    }

    // Getters e Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public boolean isDisponivel() {
        return disponivel;
    }

    public void setDisponivel(boolean disponivel) {
        this.disponivel = disponivel;
    }
}
