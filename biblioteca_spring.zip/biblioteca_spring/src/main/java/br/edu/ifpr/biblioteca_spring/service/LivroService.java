
package br.edu.ifpr.biblioteca_spring.service;

import org.springframework.stereotype.Service;

import br.edu.ifpr.biblioteca_spring.models.Livro;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicLong;

@Service
public class LivroService {

    private static final List<Livro> livros = new ArrayList<>();
    private static final AtomicLong idGenerator = new AtomicLong();

    public List<Livro> listarTodos() {
        return new ArrayList<>(livros);
    }

    public List<Livro> listarDisponiveis() {
    List<Livro> disponiveis = new ArrayList<>();
        for (Livro l : livros) {
            if (l.isDisponivel()) {
                disponiveis.add(l);
                }
            }
        return disponiveis;
    }

    public Optional<Livro> buscarPorId(Long id) {
        for (Livro l : livros) {
            if (l.getId().equals(id)) {
                return Optional.of(l);
            }
        }
        return Optional.empty();
    }

    public Livro adicionar(Livro livro) {
        livro.setId(idGenerator.incrementAndGet());
        livros.add(livro);
        return livro;
    }

    
    public void marcarComoEmprestado(Long livroId) {
        buscarPorId(livroId).ifPresent(livro -> livro.setDisponivel(false));
    }

    public void marcarComoDisponivel(Long livroId) {
        buscarPorId(livroId).ifPresent(livro -> livro.setDisponivel(true));
    }


    public void limpar() {
        livros.clear();
    }
}
