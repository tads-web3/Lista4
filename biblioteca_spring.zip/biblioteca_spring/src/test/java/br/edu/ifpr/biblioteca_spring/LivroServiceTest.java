package br.edu.ifpr.biblioteca_spring;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import br.edu.ifpr.biblioteca_spring.models.Livro;
import br.edu.ifpr.biblioteca_spring.service.LivroService;

public class LivroServiceTest {

    private LivroService livroService;

    @BeforeEach
    public void setup() {
        livroService = new LivroService();
        livroService.limpar(); 
    }

    @Test
    public void deveAdicionarLivroCorretamente() {
        Livro novoLivro = new Livro();
        novoLivro.setTitulo("O Senhor dos Anéis");
        novoLivro.setAutor("J.R.R. Tolkien");

        Livro livroAdicionado = livroService.adicionar(novoLivro);

        assertNotNull(livroAdicionado.getId(), "O ID do livro não deve ser nulo");
        assertEquals("O Senhor dos Anéis", livroAdicionado.getTitulo());
        assertEquals("J.R.R. Tolkien", livroAdicionado.getAutor());
    }

    @Test
    public void deveListarApenasLivrosDisponiveis() {
        Livro livro1 = new Livro();
        livro1.setTitulo("Livro 1");
        livro1.setAutor("Autor 1");

        Livro livro2 = new Livro();
        livro2.setTitulo("Livro 2");
        livro2.setAutor("Autor 2");

        Livro livro3 = new Livro();
        livro3.setTitulo("Livro 3");
        livro3.setAutor("Autor 3");

        // Adiciona os livros
        livroService.adicionar(livro1);
        livroService.adicionar(livro2);
        livroService.adicionar(livro3);

        // Torna um livro indisponível
        livroService.marcarComoEmprestado(livro2.getId());

        // Lista disponíveis
        List<Livro> disponiveis = livroService.listarDisponiveis();

        for (Livro l : disponiveis) {
            assertTrue(l.isDisponivel(), "Todos os livros da lista devem estar disponíveis");
            assertNotEquals(livro2.getId(), l.getId(), "Livro emprestado não deve estar na lista");
    }

    }

    @Test
    public void deveMarcarLivroComoEmprestado() {
        Livro livro = new Livro(null, "A Revolução dos Bichos", "George Orwell");
        Livro adicionado = livroService.adicionar(livro);

        livroService.marcarComoEmprestado(adicionado.getId());

        Livro resultado = livroService.buscarPorId(adicionado.getId()).orElse(null);

        assertNotNull(resultado);
        assertFalse(resultado.isDisponivel(), "O livro deve estar marcado como indisponível (emprestado)");
    }

    @Test
    public void deveMarcarLivroComoDisponivel() {

        Livro livro = new Livro(null, "Dom Casmurro", "Machado de Assis");
        Livro adicionado = livroService.adicionar(livro);

        livroService.marcarComoEmprestado(adicionado.getId());

        livroService.marcarComoDisponivel(adicionado.getId());

        Livro resultado = livroService.buscarPorId(adicionado.getId()).orElse(null);

        assertNotNull(resultado);
        assertTrue(resultado.isDisponivel(), "O livro deve estar marcado como disponível após devolução");
    }

}
