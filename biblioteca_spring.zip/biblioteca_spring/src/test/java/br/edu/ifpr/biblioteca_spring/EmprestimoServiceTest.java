package br.edu.ifpr.biblioteca_spring;

import static org.junit.jupiter.api.Assertions.*;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import br.edu.ifpr.biblioteca_spring.models.Emprestimo;
import br.edu.ifpr.biblioteca_spring.models.Livro;
import br.edu.ifpr.biblioteca_spring.models.Usuario;
import br.edu.ifpr.biblioteca_spring.service.EmprestimoService;
import br.edu.ifpr.biblioteca_spring.service.LivroService;
import br.edu.ifpr.biblioteca_spring.service.UsuariosService;

public class EmprestimoServiceTest {
    private EmprestimoService emprestimoService;
    private UsuariosService usuariosService;
    private LivroService livroService;

    @BeforeEach
    public void setup() {
        emprestimoService = new EmprestimoService();
        usuariosService = new UsuariosService();
        livroService = new LivroService();

        usuariosService.limpar();
        livroService.limpar();
    }

    @Test
    public void devePermitirEmprestimoSeUsuarioNaoBloqueadoETemMenosDe3Emprestimos() throws Exception {
        // Criar usuário e livros
        Usuario usuario = usuariosService.adicionar(new Usuario(null, "Alice", "11122233344"));

        Livro livro1 = new Livro(null, "Livro 1", "Autor A");
        Livro livro2 = new Livro(null, "Livro 2", "Autor B");
        Livro livro3 = new Livro(null, "Livro 3", "Autor C");

        livro1 = livroService.adicionar(livro1);
        livro2 = livroService.adicionar(livro2);
        livro3 = livroService.adicionar(livro3);

        //2 empréstimos para o usuário
        emprestimoService.emprestarLivro(usuario, livro1);
        emprestimoService.emprestarLivro(usuario, livro2);

        // Livro 3 deve estar disponível e empréstimo permitido
        emprestimoService.emprestarLivro(usuario, livro3);

        // Verifica se o livro 3 foi emprestado e não está disponível
        Livro livro3Buscado = livroService.buscarPorId(livro3.getId()).orElse(null);
        assertNotNull(livro3Buscado);
        assertFalse(livro3Buscado.isDisponivel());

        // Verifica quantidade de empréstimos ativos para o usuário
        long emprestimosAtivos = emprestimoService.listarTodos().stream()
            .filter(e -> e.getUsuario().getId().equals(usuario.getId()))
            .filter(e -> e.getDataDevolucaoReal() == null)
            .count();

        assertEquals(3, emprestimosAtivos);
    }

    @Test
    public void naoDevePermitirEmprestimoSeLivroIndisponivel() {
        Usuario usuario = usuariosService.adicionar(new Usuario(null, "Bob", "55544433322"));
        Livro livro = livroService.adicionar(new Livro(null, "O Senhor dos Anéis", "J.R.R. Tolkien"));
        
        // Marcar livro como indisponível para simular que está emprestado
        livro.setDisponivel(false);

        // Tenta emprestar e espera exceção
        Exception exception = assertThrows(IllegalStateException.class, () -> {
            emprestimoService.emprestarLivro(usuario, livro);
        });

        assertEquals("Livro não está disponível para empréstimo.", exception.getMessage());
}

    @Test
    public void naoDevePermitirEmprestimoSeUsuarioJaTem3Livros() {
        //usuário e 3 livros já emprestados para ele
        Usuario usuario = new Usuario();
        usuario.setNome("Usuário Teste");
        usuario.setCpf("11122233344");
        usuariosService.adicionar(usuario);

        Livro livro1 = new Livro(null, "Livro 1", "Autor 1");
        Livro livro2 = new Livro(null, "Livro 2", "Autor 2");
        Livro livro3 = new Livro(null, "Livro 3", "Autor 3");
        livroService.adicionar(livro1);
        livroService.adicionar(livro2);
        livroService.adicionar(livro3);

        // Empresta os 3 livros para o usuário
        emprestimoService.emprestarLivro(usuario, livro1);
        emprestimoService.emprestarLivro(usuario, livro2);
        emprestimoService.emprestarLivro(usuario, livro3);

        // Livro extra para tentar emprestar e falhar
        Livro livroExtra = new Livro(null, "Livro Extra", "Autor Extra");
        livroService.adicionar(livroExtra);

        //exceção ao tentar emprestar o 4º livro
        Exception exception = assertThrows(IllegalStateException.class, () -> {
            emprestimoService.emprestarLivro(usuario, livroExtra);
        });

        assertEquals("Usuário já possui 3 livros emprestados e não pode pegar mais.", exception.getMessage());
    }

    @Test
    public void naoDevePermitirEmprestimoSeUsuarioEstiverBloqueado() {
        // cria um usuário bloqueado
        Usuario usuario = new Usuario();
        usuario.setNome("Usuário Bloqueado");
        usuario.setCpf("55566677788");
        usuario.setBloqueado(true);  // usuário bloqueado
        usuariosService.adicionar(usuario);

        // Cria um livro disponível
        Livro livro = new Livro(null, "Livro Qualquer", "Autor Qualquer");
        livroService.adicionar(livro);

        // tentativa de emprestimo
        Exception exception = assertThrows(IllegalStateException.class, () -> {
            emprestimoService.emprestarLivro(usuario, livro);
        });

        assertEquals("Usuário está bloqueado e não pode realizar empréstimos.", exception.getMessage());
    }

    @Test
    public void deveCalcularDataDeDesbloqueioComBaseEmAtraso() {
        //usuario com atraso
        Usuario usuario = new Usuario();
        usuario.setNome("Usuário Atrasado");
        usuario.setCpf("11122233344");
        usuariosService.adicionar(usuario);

        Livro livro = new Livro(null, "Livro com Atraso", "Autor Teste");
        livroService.adicionar(livro);

        // prazo do emprestimo
        LocalDate dataEmprestimo = LocalDate.now().minusDays(10);
        LocalDate dataPrevista = LocalDate.now().minusDays(5); // devolução prevista 5 dias atrás

        // atraso de 5 dias
        Emprestimo emprestimo = new Emprestimo(null, usuario, livro, dataEmprestimo, dataPrevista);
        emprestimoService.emprestarLivro(usuario, livro); 

        // devolver livro atrasado
        Optional<String> resultado = emprestimoService.devolverLivro(emprestimo.getId());


        assertTrue(resultado.isEmpty(), "Devolução deve ocorrer sem erro");

        // Calcular atraso esperado: 5 dias de atraso
        // Supondo regra: bloqueio de 5 dias por livro + 1 dia por atraso = 6 dias bloqueado
        LocalDate dataEsperadaDesbloqueio = LocalDate.now().plusDays(6);

        Usuario usuarioAtualizado = usuariosService.buscarPorId(usuario.getId()).get();

        assertNotNull(usuarioAtualizado.getDataDeDesbloqueio(), "Data de desbloqueio deve estar definida");
        assertEquals(dataEsperadaDesbloqueio, usuarioAtualizado.getDataDeDesbloqueio());
    }

    @Test
    public void deveAgendarDevolucaoParaDiaUtil() {
        Usuario usuario = new Usuario();
        usuario.setNome("Usuário Teste");
        usuario.setCpf("12345678900");
        usuariosService.adicionar(usuario);

        Livro livro = new Livro(null, "Livro Teste", "Autor Teste");
        livroService.adicionar(livro);

        // emprestar o livro
        emprestimoService.emprestarLivro(usuario, livro);

        // busca o empréstimo 
        Emprestimo emprestimoCriado = emprestimoService.listarTodos().stream()
            .filter(e -> e.getUsuario().getId().equals(usuario.getId()) &&
                        e.getLivro().getId().equals(livro.getId()) &&
                        e.getDataDevolucaoReal() == null)
            .findFirst()
            .orElse(null);

        assertNotNull(emprestimoCriado, "Empréstimo criado não encontrado");

        LocalDate dataPrevista = emprestimoCriado.getDataPrevistaDevolucao();

        // Verifica se nao caiu no final de semana
        assertFalse(dataPrevista.getDayOfWeek() == DayOfWeek.SATURDAY ||
                    dataPrevista.getDayOfWeek() == DayOfWeek.SUNDAY,
                    "A data prevista de devolução não deve ser fim de semana");
    }


}
