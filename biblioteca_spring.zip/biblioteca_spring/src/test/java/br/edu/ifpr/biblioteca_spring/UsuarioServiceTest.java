package br.edu.ifpr.biblioteca_spring;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import br.edu.ifpr.biblioteca_spring.models.Usuario;
import br.edu.ifpr.biblioteca_spring.service.UsuariosService;

public class UsuarioServiceTest {
    private UsuariosService usuariosService;

    @BeforeEach
    public void setup(){
        usuariosService = new UsuariosService();
        usuariosService.limpar(); //limpa antes 
    }

    @Test
    public void deveAdicionarUmaPessoaCorretamente(){
        Usuario novoUsuario = new Usuario();
        novoUsuario.setNome("Taylor Swift");
        novoUsuario.setCpf("12345678900");

        Usuario usuarioAdd = usuariosService.adicionar(novoUsuario);

        assertNotNull(usuarioAdd, "o usuario nao pode ser nulo");
    }

    @Test
    public void deveRetornarPessoaPorIdExistente(){
        Usuario novoUsuario = new Usuario();
        novoUsuario.setNome("Harry Styles");
        novoUsuario.setCpf("99999999999");

        Usuario usuarioAdd = usuariosService.adicionar(novoUsuario);
        Long id = usuarioAdd.getId();

        Usuario usuarioBuscado = usuariosService.buscarPorId(id).orElse(null);

        assertNotNull(usuarioBuscado, "Usuário não encontrado pelo ID");
        assertEquals("Harry Styles", usuarioBuscado.getNome());
        assertEquals("99999999999", usuarioBuscado.getCpf());

    }

}

